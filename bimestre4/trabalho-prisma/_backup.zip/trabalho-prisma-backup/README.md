# Trabalho do 4º bimestre - Prisma API

```console
git clone https://github.com/juanmadeira/ds1-2024
cd bimestre4/trabalho-prisma
npm install express prisma @prisma/client body-parser
npx prisma init
npx prisma migrate dev --name init
npx prisma generate
```